<font size="5">$\huge1.INTRODUCTION $</font>.

<font size="3"> In this project, we will explore the "nhanes_adult_male_bmx_2020(in)" and "nhanes_adult_female_bmx_2020 2(in)" datasets, which contain body measurement data for adult males and females. The <code>**male dataset**</code> consists of <mark>**4099**</mark> instances with <mark>**7**</mark> attributes, while the <code>**female dataset** </code> of <mark>**4239**</mark> instances with <mark>**7**</mark> attributes.In this study,I will perform Exploratory Data Analysis (EDA) and test different regression algorithms to <code> predict the female dataset</code> based on other information. Then I will discuss the results and see which algorithm works best. Additionally, I will visualize the data to better understand the relationships between the variables.</font>




1. **INTRODUCTION**
2. **USED LIBRARIES**
3. **DATA EXPLORATION**

    **3.1. Detailed Information of the Dataset**

    **3.2. Exploratory Data Analysis**

    **3.3. Explore problems within variables**

    **3.4. Various Visualizations from Dataset**

4. **DATA PREPARATION AND CLEANING**
    
    **4.1. standarization of Data**

    **4.2. Correction of Column(Attribute) Names** 

    **4.3. Discover patterns and relationships**

    **4.4. Split Data and Target**
    
    **4.4. Preparation of Test and Train Data**
    
    **4.5. Hypothesis Testing**

    **4.6. Visualizations from FEMALEBMI(target variable)**
    
5. **BUILDING MODELS**
    
    **5.1. Multiple Linear Regression**
    
    **5.2. Polynomial Regression**

    **5.3. Model Selection**

6. **EVALUATING MODELS**

    **6.1. Evaluating Multiple Linear Regression Model**

7. **EXPLORATION OF RESULTS**

8. **CONCLUSION**

## <font size="5">2.Importing LIBRARIES</font>


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from scipy.stats import pearsonr, spearmanr
import seaborn as sns
from sklearn.preprocessing import StandardScaler

```

## <font size="5"> 3. DATA EXPLORATION</font>

<font size='3'>In this section, various explanations will be made about dataset.</font>

### <font size='5'>3.1. Detailed Information of the Dataset</font>


<font size='3'>Here I will import the dataset first. Then, I will explain the columns(features) of the dataset one by one.</font>

<font size='3'> Import dataset  #Read csv file in both male_data and female_data and load into 'data variable'</font>



```python
import pandas as pd
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")  
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")  
```

### <font size='5'>3.2. Exploratory Data Analysis</font>

<font size='3'>Now , i will explore the data both male and female to gain insights about the data.</font>



```python
import pandas as pd
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")  
male_data.shape   # view dimensions of dataset
```




    (4099, 7)



<font size='3'>We can see that there are **(4099)** instances and **(7)** attributes in the data set.</font>


```python
import pandas as pd
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")  
female_data.shape   # view dimensions of dataset
```




    (4239, 7)



<font size='3'>We can see that there are **(4239)** instances and **(7)** attributes in the data set.</font>

### View top 10 rows of male_dataset 


```python
import pandas as pd
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")  
male_data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BMXWT</th>
      <th>BMXHT</th>
      <th>BMXARML</th>
      <th>BMXLEG</th>
      <th>BMXARMC</th>
      <th>BMXHIP</th>
      <th>BMXWAIST</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>98.8</td>
      <td>182.3</td>
      <td>42.0</td>
      <td>40.1</td>
      <td>38.2</td>
      <td>108.2</td>
      <td>120.4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>74.3</td>
      <td>184.2</td>
      <td>41.1</td>
      <td>41.0</td>
      <td>30.2</td>
      <td>94.5</td>
      <td>86.8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>103.7</td>
      <td>185.3</td>
      <td>47.0</td>
      <td>44.0</td>
      <td>32.0</td>
      <td>107.8</td>
      <td>109.6</td>
    </tr>
    <tr>
      <th>3</th>
      <td>86.0</td>
      <td>167.8</td>
      <td>39.5</td>
      <td>38.4</td>
      <td>29.0</td>
      <td>106.4</td>
      <td>108.3</td>
    </tr>
    <tr>
      <th>4</th>
      <td>99.4</td>
      <td>181.6</td>
      <td>40.4</td>
      <td>39.9</td>
      <td>36.0</td>
      <td>120.2</td>
      <td>107.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>90.2</td>
      <td>162.5</td>
      <td>38.7</td>
      <td>38.0</td>
      <td>37.3</td>
      <td>110.2</td>
      <td>116.2</td>
    </tr>
    <tr>
      <th>6</th>
      <td>45.5</td>
      <td>159.3</td>
      <td>36.2</td>
      <td>38.0</td>
      <td>24.4</td>
      <td>82.0</td>
      <td>67.2</td>
    </tr>
    <tr>
      <th>7</th>
      <td>64.0</td>
      <td>174.9</td>
      <td>37.0</td>
      <td>45.0</td>
      <td>29.2</td>
      <td>88.9</td>
      <td>82.5</td>
    </tr>
    <tr>
      <th>8</th>
      <td>67.9</td>
      <td>166.2</td>
      <td>37.3</td>
      <td>40.3</td>
      <td>31.0</td>
      <td>93.4</td>
      <td>87.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>75.2</td>
      <td>172.6</td>
      <td>38.6</td>
      <td>41.5</td>
      <td>32.0</td>
      <td>96.4</td>
      <td>95.0</td>
    </tr>
  </tbody>
</table>
</div>



## View top 10 rows of female_dataset 


```python
import pandas as pd
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")  
female_data.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BMXWT</th>
      <th>BMXHT</th>
      <th>BMXARML</th>
      <th>BMXLEG</th>
      <th>BMXARMC</th>
      <th>BMXHIP</th>
      <th>BMXWAIST</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>97.1</td>
      <td>160.2</td>
      <td>34.7</td>
      <td>40.8</td>
      <td>35.8</td>
      <td>126.1</td>
      <td>117.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>91.1</td>
      <td>152.7</td>
      <td>33.5</td>
      <td>33.0</td>
      <td>38.5</td>
      <td>125.5</td>
      <td>103.1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>73.0</td>
      <td>161.2</td>
      <td>37.4</td>
      <td>38.0</td>
      <td>31.8</td>
      <td>106.2</td>
      <td>92.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>61.7</td>
      <td>157.4</td>
      <td>38.0</td>
      <td>34.7</td>
      <td>29.0</td>
      <td>101.0</td>
      <td>90.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>55.4</td>
      <td>154.6</td>
      <td>34.6</td>
      <td>34.0</td>
      <td>28.3</td>
      <td>92.5</td>
      <td>73.2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>62.0</td>
      <td>144.7</td>
      <td>32.5</td>
      <td>34.2</td>
      <td>29.8</td>
      <td>106.7</td>
      <td>84.8</td>
    </tr>
    <tr>
      <th>6</th>
      <td>66.2</td>
      <td>166.5</td>
      <td>37.5</td>
      <td>37.6</td>
      <td>32.0</td>
      <td>96.3</td>
      <td>95.7</td>
    </tr>
    <tr>
      <th>7</th>
      <td>75.9</td>
      <td>154.5</td>
      <td>35.4</td>
      <td>37.6</td>
      <td>32.7</td>
      <td>107.7</td>
      <td>98.7</td>
    </tr>
    <tr>
      <th>8</th>
      <td>77.2</td>
      <td>159.2</td>
      <td>38.5</td>
      <td>40.5</td>
      <td>35.7</td>
      <td>102.0</td>
      <td>97.5</td>
    </tr>
    <tr>
      <th>9</th>
      <td>91.6</td>
      <td>174.5</td>
      <td>36.1</td>
      <td>45.9</td>
      <td>35.2</td>
      <td>121.3</td>
      <td>100.3</td>
    </tr>
  </tbody>
</table>
</div>



## View summary of dataset for both male and female



```python
male_data.info()   ### View summary of dataset

female_data.info()  ### View summary of dataset
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4099 entries, 0 to 4098
    Data columns (total 7 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   BMXWT     4099 non-null   float64
     1   BMXHT     4099 non-null   float64
     2   BMXARML   4099 non-null   float64
     3   BMXLEG    4099 non-null   float64
     4   BMXARMC   4099 non-null   float64
     5   BMXHIP    4099 non-null   float64
     6   BMXWAIST  4099 non-null   float64
    dtypes: float64(7)
    memory usage: 224.3 KB
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 4239 entries, 0 to 4238
    Data columns (total 7 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   BMXWT     4239 non-null   float64
     1   BMXHT     4239 non-null   float64
     2   BMXARML   4239 non-null   float64
     3   BMXLEG    4239 non-null   float64
     4   BMXARMC   4239 non-null   float64
     5   BMXHIP    4239 non-null   float64
     6   BMXWAIST  4239 non-null   float64
    dtypes: float64(7)
    memory usage: 231.9 KB
    

## Check data types of columns of dataframe in both male and female dataset



```python
import pandas as pd
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")  
male_data.dtypes   ### Check data types of columns of dataframe
```




    BMXWT       float64
    BMXHT       float64
    BMXARML     float64
    BMXLEG      float64
    BMXARMC     float64
    BMXHIP      float64
    BMXWAIST    float64
    dtype: object




```python
import pandas as pd
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")  
female_data.dtypes   ### Check data types of columns of dataframe
```




    BMXWT       float64
    BMXHT       float64
    BMXARML     float64
    BMXLEG      float64
    BMXARMC     float64
    BMXHIP      float64
    BMXWAIST    float64
    dtype: object



<font size='3'>Now, we can see that all the columns of the dataframe are of type numeric.</font>

 <font size='3'>Summary of variables: 
 
 **-->** There are <code>7 numerical variables</code> in the dataset. 
 
 **-->** All of the variables are of <code>continuous type</code>.</font>


## 3.3. Explore problems within variables


<font size='3'>Now, I will explore problems within variables. Missing values in variables.</font>


```python
import pandas as pd
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")
male_data_df=pd.DataFrame(male_data)
male_data_df.isnull().sum()
```




    BMXWT       0
    BMXHT       0
    BMXARML     0
    BMXLEG      0
    BMXARMC     0
    BMXHIP      0
    BMXWAIST    0
    dtype: int64




```python
import pandas as pd
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")
female_data_df=pd.DataFrame(female_data)
female_data_df.isnull().sum()
```




    BMXWT       0
    BMXHT       0
    BMXARML     0
    BMXLEG      0
    BMXARMC     0
    BMXHIP      0
    BMXWAIST    0
    dtype: int64



<font size='3'>Now ,we can see our dataset have <code>no missing value(NaN)</code></font>.


## <font size='3'> Let's see the various statistics about the numeric data.</font>


```python
import pandas as pd
# view summary statistics in numerical variables
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")  
male_data_df=pd.DataFrame(male_data)
#print(male_data_df.describe(),1)
print(round(male_data_df.describe(),1))
```

            BMXWT   BMXHT  BMXARML  BMXLEG  BMXARMC  BMXHIP  BMXWAIST
    count  4099.0  4099.0   4099.0  4099.0   4099.0  4099.0    4099.0
    mean     88.4   173.8     39.2    41.3     34.3   104.5     101.8
    std      21.4     7.7      2.4     3.2      4.8    12.2      16.6
    min      36.8   144.6     29.6    27.5     19.0    77.0      62.3
    25%      73.3   168.6     37.6    39.2     31.0    96.0      90.1
    50%      85.0   173.8     39.1    41.2     34.0   102.7     100.5
    75%      99.8   178.9     40.9    43.5     37.3   110.6     112.0
    max     204.6   199.6     49.9    53.0     53.6   174.9     170.8
    


```python
# view summary statistics in numerical variables
import pandas as pd
# view summary statistics in numerical variables
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")
female_data_df=pd.DataFrame(female_data)
print(round(female_data_df.describe(),1))
```

            BMXWT   BMXHT  BMXARML  BMXLEG  BMXARMC  BMXHIP  BMXWAIST
    count  4239.0  4239.0   4239.0  4239.0   4239.0  4239.0    4239.0
    mean     77.4   160.1     36.0    37.2     32.7   109.2      98.5
    std      21.5     7.1      2.3     3.2      5.6    15.6      17.4
    min      32.6   131.1     28.5    25.0     17.9    74.0      56.4
    25%      61.6   155.3     34.4    35.0     28.7    97.7      86.0
    50%      73.6   160.1     36.0    37.1     32.1   106.7      97.1
    75%      88.7   164.8     37.5    39.3     36.1   117.9     109.4
    max     180.9   189.3     46.7    49.1     57.2   179.0     178.0
    

<font size='3'>Next , <code>DataFrame</code> change into numpy matrices named **'male'** and **'female'**, each with **7** columns: <code>weight, height, upper arm length, upper leg length, arm circumference, hip circumference, and waist circumference</code>.</font>



```python
import numpy as np
# Load the data from the CSV files into numpy matrices
male = np.genfromtxt('nhanes_adult_male_bmx_2020(in).csv', delimiter=',')
female = np.genfromtxt('nhanes_adult_female_bmx_2020 2(in).csv', delimiter=',')

# Check the shape of the matrices
print(male.shape)  # Should print (num_rows, 7)
print(female.shape)  # Should print (num_rows, 7)
```

    (4100, 7)
    (4240, 7)
    

<font size='3'>**Two datasets** is successfully converted into numpy matrices.</font>


## 3.4. Various Visualizations from Dataset
 
<font size='3'>Now, we have a basic understanding of our data. I will supplement it with some data visualization to get better understanding
of our data.</font>

<font size='3'>Plot **histograms** of <code>female and male weights</code>
I'll create a single plot with <code>two subfigures</code> using matplotlib.pyplot.subplot. The <code>top subfigure</code> will show the histogram of **female weights**, and the <code>bottom subfigure</code> will show the histogram of **male weights**. I'll set the <code>x-axis limits</code> to be identical for both subfigures.
Check the distribution of variables.
Now, I will plot the histograms to check variable distributions to find out if they are <code>normal</code> or <code>skewed</code>.</font>


```python
import matplotlib.pyplot as plt
import pandas as pd

male_data = pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Create a figure with two subplots
fig, axs = plt.subplots(2, 1, figsize=(8, 7))

# Plot the histogram of female weights on the top subplot
#axs[0].hist(female_data.iloc[:, 0], bins=20)
axs[0].hist(female_data.iloc[:, 0], bins=20, color='green', alpha=0.5, label='Female') # Assuming weight is the first column
axs[0].set_title('Female Weights')
axs[0].set_xlabel('Weight (kg)')
axs[0].set_ylabel('Frequency')
axs[0].legend()

# Plot the histogram of male weights on the bottom subplot
#axs[1].hist(male_data.iloc[:, 0], bins=20)  # Assuming weight is the first column
axs[1].hist(male_data.iloc[:, 0], bins=20, color='blue', alpha=0.5, label='Male')
axs[1].set_title('Male Weights')
axs[1].set_xlabel('Weight (kg)')
axs[1].set_ylabel('Frequency')
axs[1].legend()

# Set the x-axis limits to be identical for both subfigures
axs[0].set_xlim([0, 250])  # Adjust the limits as needed
axs[1].set_xlim([0, 250])

# Show the plot
plt.tight_layout()
plt.show()
```


    
![png](output_35_0.png)
    


<font size='3'>We can see that all the variables in the <mark>two datasets</mark> are <code>positively skewed</code>.</font>


<font size='3'>Now,Create a <code>box-and-whisker plot</code> for <code>male and female weights</code>
I'll use matplotlib.pyplot.boxplot to create a box-and-whisker plot with <code>two boxes side by side</code>, showing the distribution of male and female weights.


```python
import warnings
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Ignore MatplotlibDeprecationWarning
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Read CSV files
male_data = pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Assuming you have the female and male weights in two separate arrays
female_weights = np.random.normal(60, 10, 100)
male_weights = np.random.normal(70, 12, 100)

# Assign the arrays to female_data and male_data
female_data = female_weights
male_data = male_weights

# Create a figure and axis
fig, ax = plt.subplots()

# Create a box-and-whisker plot with two boxes side by side
ax.boxplot([female_data, male_data], labels=['Female', 'Male'], boxprops=dict(facecolor='yellow', color='black'), flierprops=dict(markerfacecolor='red', markersize=6), medianprops=dict(color='red'), whiskerprops=dict(color='green'), patch_artist=True)

# Set title and labels
ax.set_title('Box-and-Whisker Plot of Weights')
ax.set_xlabel('Gender')
ax.set_ylabel('Weight')

# Show the plot
#plt.title("Weight Distribution")
plt.show()


```


    
![png](output_38_0.png)
    


## Compute numerical aggregates and compare distributions
<font size='3'>I'll compute basic numerical aggregates <code>(measures of location, dispersion, and shape)</code> for **male** and**female** weights of the two distributions.</font>


```python
import numpy as np
import pandas as pd
import scipy.stats as stats
#Male Weight to perform Aggregation functions
male_data=pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")
male_data = male_data.to_numpy()
male_data_agg = np.array([np.mean(male_data[:, 0]), np.median(male_data[:, 0]), np.std(male_data[:, 0]), stats.skew(male_data[:, 0])])

#Female Weight to perform Aggregation functions
female_data=pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")
female_data = female_data.to_numpy()
female_data_agg = np.array([np.mean(female_data[:, 0]), np.median(female_data[:, 0]), np.std(female_data[:, 0]),stats.skew(female_data[:,0])])
print("1.)Male Weight Aggregates:")
print("Mean:", male_data_agg[0])
print("Median:", male_data_agg[1])
print("Standard Deviation:", male_data_agg[2])
print("Skewness:", male_data_agg[3])
print("2.)Female Weight Aggregates:")
print("Mean:", female_data_agg[0])
print("Median:", female_data_agg[1])
print("Standard Deviation:", female_data_agg[2])
print("Skewness:", female_data_agg[3])

# Compare the distributions
print("3.)Comparison:")
print("The mean weight of (males) is", male_data_agg[0], "kg, while the mean weight of (females) is", female_data_agg[0], "kg.")
print("The median weight of (males) is", male_data_agg[1], "kg, while the median weight of (females) is", female_data_agg[1], "kg.")
print("The standard deviation of (male) weights is", male_data_agg[2], "kg, while the standard deviation of (female) weights is", female_data_agg[2], "kg.")
print("The skewness of (male) weights is", male_data_agg[3], "while the skewness of (female) weights is", female_data_agg[3], ".")

```

    1.)Male Weight Aggregates:
    Mean: 88.35977067577458
    Median: 85.0
    Standard Deviation: 21.423533128235817
    Skewness: 0.9829085611217528
    2.)Female Weight Aggregates:
    Mean: 77.40172210426988
    Median: 73.6
    Standard Deviation: 21.53736778800556
    Skewness: 1.0323276715001954
    3.)Comparison:
    The mean weight of (males) is 88.35977067577458 kg, while the mean weight of (females) is 77.40172210426988 kg.
    The median weight of (males) is 85.0 kg, while the median weight of (females) is 73.6 kg.
    The standard deviation of (male) weights is 21.423533128235817 kg, while the standard deviation of (female) weights is 21.53736778800556 kg.
    The skewness of (male) weights is 0.9829085611217528 while the skewness of (female) weights is 1.0323276715001954 .
    

### Interpretation of the comparison result:
<font size='3'> **-->** **Males tend to weight more than females**, with a **higher mean weight** <code>(88.36 kg vs 77.4 kg).</code></font>

<font size='3'> **-->** The **median weight of males** <code>(85 kg)</code> is also **higher than that of females** <code>(73.6 kg)</code>,suggesting that 
                             the <code>majority of **males weight more than the majority of females**.</code></font>

<font size='3'> **-->** Both distributions have <code>similar standard deviations</code>, meaning the **spread of weights** is <code>similar.</code></font>

<font size='3'> **-->** **Males** have a slightly more <code>symmetrical distribution</code>, while **females** have a slightly more <code>skewed distribution</code>.</font>


<font size='3'>Add a **new column** for <code>body mass indices</code> **(FEMALEBMIs)** to the **female matrix**
I'll add a new column to the female matrix containing the BMIs of all female participants.</font>


```python
import pandas as pd
import numpy as np
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")
# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)  # weight (kg) / height (m)^2


# Add the new column
female_data['FEMALEBMI'] = female_bmi


print(female_data)
#print(female_data[:,7])


```

          BMXWT  BMXHT  BMXARML  BMXLEG  BMXARMC  BMXHIP  BMXWAIST  FEMALEBMI
    0      97.1  160.2     34.7    40.8     35.8   126.1     117.9   0.003784
    1      91.1  152.7     33.5    33.0     38.5   125.5     103.1   0.003907
    2      73.0  161.2     37.4    38.0     31.8   106.2      92.0   0.002809
    3      61.7  157.4     38.0    34.7     29.0   101.0      90.5   0.002490
    4      55.4  154.6     34.6    34.0     28.3    92.5      73.2   0.002318
    ...     ...    ...      ...     ...      ...     ...       ...        ...
    4234   66.8  157.0     32.6    38.4     30.7   103.8      92.5   0.002710
    4235  116.9  167.4     42.2    43.0     40.7   128.4     120.0   0.004172
    4236   73.0  159.6     36.2    37.0     31.4   104.6      99.3   0.002866
    4237   78.6  168.5     38.1    40.2     36.0   102.4      98.5   0.002768
    4238   82.8  147.8     34.8    32.8     39.5   121.4     110.0   0.003790
    
    [4239 rows x 8 columns]
    

<font size='3'> Now ,we can see our **dataset add the new column** containing **FEMALEBMIs is successfully added** to the <code>female matrix.</code></font>

## 4.1. standarization of Data

<font size='3'>Standardize the **female matrix**
I'll create a new matrix **'zfemale'** which is a **standardized** version of the female dataset, with all columns standardized (**z-scores** computed).</font>


```python
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

print(zfemale_df)

```

             BMXWT     BMXHT   BMXARML    BMXLEG   BMXARMC    BMXHIP  BMXWAIST  \
    0     0.914609  0.008883 -0.567445  1.132372  0.551435  1.083930  1.116205   
    1     0.636024 -1.053643 -1.079106 -1.294369  1.033081  1.045508  0.265635   
    2    -0.204376  0.150553  0.583791  0.261234 -0.162114 -0.190405 -0.372292   
    3    -0.729046 -0.387793  0.839621 -0.765464 -0.661598 -0.523398 -0.458499   
    4    -1.021560 -0.784469 -0.610084 -0.983248 -0.786469 -1.067712 -1.452746   
    ...        ...       ...       ...       ...       ...       ...       ...   
    4234 -0.492248 -0.444461 -1.462851  0.385682 -0.358340 -0.344094 -0.343557   
    4235  1.833942  1.028908  2.630432  1.816837  1.425533  1.231216  1.236894   
    4236 -0.204376 -0.076119  0.072130 -0.049886 -0.233469 -0.292865  0.047246   
    4237  0.055637  1.184745  0.882259  0.945700  0.587112 -0.433746  0.001269   
    4238  0.250647 -1.747826 -0.524807 -1.356593  1.211468  0.782957  0.662185   
    
          FEMALEBMI  
    0      0.997315  
    1      1.156560  
    2     -0.259228  
    3     -0.670443  
    4     -0.893004  
    ...         ...  
    4234  -0.387195  
    4235   1.497881  
    4236  -0.186217  
    4237  -0.311986  
    4238   1.006169  
    
    [4239 rows x 8 columns]
    

<font size='3'>The standardized female matrix **'zfemale'** is **successfully created**.<font>


## 4.2. Correction of Column(Attribute) Names

<font size='3'>Draw a **scatterplot** matrix and compute **correlation coefficients**
I'll create a scatterplot matrix **(pairplot)** for the standardized versions of <code>height, weight, waist circumference, hip circumference, and BMI of females (based on 'zfemale')</code>. Then, you'll compute **Pearson's and Spearman's**correlation coefficients for all pairs of variables and interpret the results.</font>


```python
import pandas as pd
import numpy as np
import matplotlib .pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler

female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

#print(zfemale_df)

# Create a scatterplot matrix (pairplot) for the standardized variables hue='FEMALEBMI'
sns.pairplot(zfemale_df, diag_kind='kde')
plt.show()

# Compute Pearson's correlation coefficients
pearson_corr = zfemale_df.corr()
print("(Pearson's) Correlation Coefficients:")
print(pearson_corr)

# Compute Spearman's rank correlation coefficients
spearman_corr = zfemale_df.corr(method='spearman')
print("(Spearman's) Rank Correlation Coefficients:")
print(spearman_corr)

```


    
![png](output_51_0.png)
    


    (Pearson's) Correlation Coefficients:
                  BMXWT     BMXHT   BMXARML    BMXLEG   BMXARMC    BMXHIP  \
    BMXWT      1.000000  0.345344  0.551880  0.194368  0.905355  0.946562   
    BMXHT      0.345344  1.000000  0.667788  0.656829  0.151576  0.202416   
    BMXARML    0.551880  0.667788  1.000000  0.475830  0.453247  0.459494   
    BMXLEG     0.194368  0.656829  0.475830  1.000000  0.080539  0.101186   
    BMXARMC    0.905355  0.151576  0.453247  0.080539  1.000000  0.868183   
    BMXHIP     0.946562  0.202416  0.459494  0.101186  0.868183  1.000000   
    BMXWAIST   0.904475  0.126385  0.428044 -0.033727  0.845180  0.897337   
    FEMALEBMI  0.945916  0.032943  0.365015 -0.013444  0.915455  0.944328   
    
               BMXWAIST  FEMALEBMI  
    BMXWT      0.904475   0.945916  
    BMXHT      0.126385   0.032943  
    BMXARML    0.428044   0.365015  
    BMXLEG    -0.033727  -0.013444  
    BMXARMC    0.845180   0.915455  
    BMXHIP     0.897337   0.944328  
    BMXWAIST   1.000000   0.921124  
    FEMALEBMI  0.921124   1.000000  
    (Spearman's) Rank Correlation Coefficients:
                  BMXWT     BMXHT   BMXARML    BMXLEG   BMXARMC    BMXHIP  \
    BMXWT      1.000000  0.338711  0.541854  0.196849  0.913899  0.946653   
    BMXHT      0.338711  1.000000  0.665270  0.646824  0.144660  0.204909   
    BMXARML    0.541854  0.665270  1.000000  0.464299  0.424124  0.449524   
    BMXLEG     0.196849  0.646824  0.464299  1.000000  0.077250  0.119841   
    BMXARMC    0.913899  0.144660  0.424124  0.077250  1.000000  0.873866   
    BMXHIP     0.946653  0.204909  0.449524  0.119841  0.873866  1.000000   
    BMXWAIST   0.900083  0.108639  0.402530 -0.041701  0.843329  0.887904   
    FEMALEBMI  0.938005  0.019772  0.341013 -0.019195  0.922832  0.934345   
    
               BMXWAIST  FEMALEBMI  
    BMXWT      0.900083   0.938005  
    BMXHT      0.108639   0.019772  
    BMXARML    0.402530   0.341013  
    BMXLEG    -0.041701  -0.019195  
    BMXARMC    0.843329   0.922832  
    BMXHIP     0.887904   0.934345  
    BMXWAIST   1.000000   0.922906  
    FEMALEBMI  0.922906   1.000000  
    

<font size='3'>The scatterplot matrix shows the relationships between the variables.</font>

<font size='3'>showing the correlation coefficients for each pair of variables. 
I can interpret the results by looking at the values of the correlation coefficients, which **range** from **-1 (perfect negative correlation)** to **1 (perfect positive correlation)**.</font>

# **Interpret the result:**

<font size='3'>**(Pearson's)** Correlation Coefficients:</font>

<font size='3'> **-->** **Most body** measurements are related to each other and tend to **increase** or **decrease together**.</font>

<font size='3'> **-->** **Weight (BMXWT)** and **hip circumference (BMXHIP)** are the <code>most closely related, with a correlation</code> of **0.946562**.</font>

<font size='3'>  **-->** **Leg length (BMXLEG)** and **arm circumference (BMXARMC)** are the <code>least closely related, with a correlation</code> of **0.080539**.</font>

<font size='3'> **-->** **BMI (FEMALEBMI)** is <code>related to most other body measurements</code>.</font>




<font size='3'>**(Spearman's Rank)** Correlation Coefficients:</font>

<font size='3'> **-->** **Similar results** to **Pearson's correlation** coefficients, with some **small differences**.</font>

<font size='3'> **-->** **Weight (BMXWT)** and **hip circumference (BMXHIP)** are still the <code>most closely related, with a correlation</code> of **0.946653.**</font>

 <font size='3'> **-->** **Leg length (BMXLEG)** and **arm circumference (BMXARMC)** are still the <code>least closely related, with a correlation</code> of **0.077250.**</font>

<font size='3'> **-->** **BMI (FEMALEBMI)** is still <code>related to most other body measurements.</code></font>

## <font size='3'>**Overall the comparsion** :</font>

<font size='3'> **-->** Most **body** measurements are **related** to each other.</font>

<font size='3'> **-->** **BMI (FEMALEBMI)** is a **good** indicator of **overall body size and shape.**</font>

<font size='3'> **-->** Some measurements, like **leg length and arm circumference**, may **not be as closely** related.</font>

## 4.3. Discover patterns and relationships

<font size='3'>An important step in EDA is to discover patterns and relationships between variables in the dataset. I will use the **seaborn heatmap** to explore the <code>patterns and relationships</code> in the dataset.</font>



```python

import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, spearmanr

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Calculate the correlation matrix
corr_matrix = zfemale_df.corr()

# Create a heatmap of the correlation matrix
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, cmap='plasma', square=True, vmin=-1, vmax=1,cbar_kws={'shrink': 0.5})
plt.title("Correlation Matrix of Standardized Female Body Measurements")
plt.show()
```


    
![png](output_58_0.png)
    


## Correlation Analysis
<font size='3'>From the above **correlation heat map**, we can conclude that :-</font>

<font size='3'> **-->** **BMXWT (weight)(correlation coefficient=0.95)**, is **highly correlated** with **BMXHIP (hip circumference)(correlation coefficient=0.94)**, and **BMXWAIST (waist circumference)(correlation coefficient=0.92)**.</font>

<font size='3'> **-->** **BMXHT (height)(correlation coefficient=0.033)**, is **positively correlated** with **BMXLEG (leg length)(correlation coefficient=-0.013)**, and **BMXARMC (arm circumference)(correlation coefficient=0.92)**.</font>

<font size='3'> **-->** **FEMALEBMI (BMI)(correlation coefficient=1)**, is **highly correlated** with **BMXWT (weight)(correlation coefficient=0.95)**,and **BMXHIP (hip circumference)(correlation coefficient=0.94)**,and **BMXWAIST (waist circumference)(correlation coefficient=0.92)**.</font>

<font size='3'> Compute **waist circumference to height and hip circumference ratios**
I'll add two new columns to the male and female matrices, containing the **waist circumference to height ratio and the waist circumference to hip circumference ratio**.</font>


```python
import numpy as np
import pandas as pd

male_data = pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Ensure the data has enough columns
male_data = male_data.to_numpy()
female_data = female_data.to_numpy()

# Add a new column for the ratio
male_data = np.hstack((male_data, np.zeros((male_data.shape[0], 1))))
female_data = np.hstack((female_data, np.zeros((female_data.shape[0], 1))))

# Truncate the longer array to match the shape of the shorter array
min_len = min(male_data.shape[0], female_data.shape[0])
male_data = male_data[:min_len]
female_data = female_data[:min_len]

#Waist Circumference (WC) = π x (Waist Diameter)  //Where:Waist Diameter is the measurement around the narrowest part of the natural waistline
# Compute waist circumference
#waist_circumference = np.pi * (male_data[:, 1] + female_data[:, 1])

waist_circumference_male = np.pi * male_data[:, 6]
waist_circumference_female = np.pi * female_data[:, 6]

#However, if you only have the waist circumference values and want to calculate the ratio, you can use the formula:
#waist_to_height_ratio = waist_circumference / height

# Compute waist-to-height ratio for male
waist_to_height_ratio_male = waist_circumference_male / male_data[:, 1]
# Compute waist-to-height ratio for females
waist_to_height_ratio_female = waist_circumference_female / female_data[:, 1]


print("(Male) Waist-to-(Height) Ratio:")
print(waist_to_height_ratio_male)
print("(Female) Waist-to-(Height) Ratio:")
print(waist_to_height_ratio_female)

#To calculate the waist-to-hip circumference ratio (WHR), you can use the formula:
#WHR = Waist Circumference / Hip Circumference

# Compute waist-to-hip ratio for males
waist_to_hip_ratio_male = male_data[:, 6] / male_data[:, 5]

# Compute waist-to-hip ratio for females
waist_to_hip_ratio_female = female_data[:, 6] / female_data[:, 5]
print("(Male) Waist-to-(Hip) Ratio:")
print(waist_to_hip_ratio_male)
print("(Female) Waist-to-(Hip) Ratio:")
print(waist_to_hip_ratio_female)

```

    (Male) Waist-to-(Height) Ratio:
    [2.07486426 1.48040305 1.85816813 ... 2.13598505 1.72930072 1.62987702]
    (Female) Waist-to-(Height) Ratio:
    [2.312071   2.12114082 1.79296851 ... 1.60539536 2.1416371  1.76985325]
    (Male) Waist-to-(Hip) Ratio:
    [1.11275416 0.91851852 1.01669759 ... 0.9720339  0.97294589 0.96022099]
    (Female) Waist-to-(Hip) Ratio:
    [0.93497224 0.82151394 0.86629002 ... 0.85744456 0.83053435 0.91568837]
    

<font size='3'>**(Male)** Waist-to-**(Height)** Ratio:</font>

**-> Average ratio: 1.83**

**-> Range: 1.48 to 2.14**

<font size='3'>**(Female)** Waist-to-**(Height)** Ratio:</font>

**-> Average ratio: 1.93**

**-> Range: 1.60 to 2.31**

<font size='3'>**(Male)** Waist-to-**(Hip)** Ratio:</font>

**-> Average ratio: 1.01**

**-> Range: 0.92 to 1.11**

<font size='3'>**(Female)** Waist-to-**(Hip)** Ratio:</font>

**-> Average ratio: 0.88**

**-> Range: 0.82 to 0.97**

**Note**: The ratios are used to understand body shape and health risks. 

<font size='3'>Draw a **box-and-whisker plot** for ratios
I'll create a box-and-whisker plot with **four boxes side by side,** comparing the distribution of the **waist-to-height ratio** and the **waist-to-hip ratio** of both **male** and **female** participants.</font>


```python
import warnings
# Ignore MatplotlibDeprecationWarning
warnings.filterwarnings("ignore", category=DeprecationWarning)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Load the data
male_data = pd.read_csv("nhanes_adult_male_bmx_2020(in).csv")
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Ensure the data has enough columns
male_data = male_data.to_numpy()
female_data = female_data.to_numpy()

# Add a new column for the ratio
male_data = np.hstack((male_data, np.zeros((male_data.shape[0], 1))))
female_data = np.hstack((female_data, np.zeros((female_data.shape[0], 1))))

# Truncate the longer array to match the shape of the shorter array
min_len = min(male_data.shape[0], female_data.shape[0])
male_data = male_data[:min_len]
female_data = female_data[:min_len]

# Compute waist circumference
waist_circumference_male = np.pi * male_data[:, 1]
waist_circumference_female = np.pi * female_data[:, 1]

# Compute waist-to-height ratio
waist_to_height_ratio_male = waist_circumference_male / male_data[:, 1]
waist_to_height_ratio_female = waist_circumference_female / female_data[:, 1]

# Compute waist-to-hip ratio
waist_to_hip_ratio_male = male_data[:, 6] / male_data[:, 5]
waist_to_hip_ratio_female = female_data[:, 6] / female_data[:, 5]


# Create a box-and-whisker plot
fig, ax = plt.subplots()
ax.boxplot([waist_to_height_ratio_male, waist_to_height_ratio_female, waist_to_hip_ratio_male, waist_to_hip_ratio_female],
           labels=['Male W(H)R', 'Female W(H)R', 'Male W(HIP)R', 'Female W(HIP)R'],
           boxprops=dict(facecolor='yellow',color='black'),  # color for the box
           flierprops=dict(color='red',markersize=6),  # color for the outliers
           medianprops=dict(color='red'),  # color for the median line
           whiskerprops=dict(color='green'), # color for the whiskers
           showfliers=True, showbox=True,
           patch_artist=True
          )
ax.set_title('Box-and-Whisker Plot of Ratios')
ax.set_xlabel('Ratio Type')
ax.set_ylabel('Ratio Value')
plt.show()
```


    
![png](output_64_0.png)
    


 <font size='3'>I will discuss the **Advantages** and **Disadvantages** of BMI, <code>waist-to-height ratio, and waist-to-hip ratio.</code></font>

<font size='4'> **-->BMI (Body Mass Index)**</font>

<font size='3'>**(Advantages)**:</font>

<font size='3'>1.)- Easy to calculate and understand.</font>

<font size='3'>2.)- Quick and inexpensive way to assess weight status.</font>

<font size='3'>3.)- Can identify potential health risks associated with excess weight.</font>

<font size='3'>**(Disadvantages)**:</font>

<font size='3'>1.)- Does not distinguish between muscle and fat mass.</font>

<font size='3'>2.)- May not accurately reflect health risks for athletes or individuals with high muscle mass.</font>

<font size='3'>3.)- Can be misleading for short or tall individuals.</font>


<font size='4'>**-->Waist-to-Height Ratio (WHTR)**</font>

<font size='3'>**(Advantages)**:</font>

<font size='3'>1.)- More accurate than BMI for assessing health risks associated with excess fat around the waist.</font>

<font size='3'>2.)- Can identify increased risk for chronic diseases like diabetes and cardiovascular disease.</font>

<font size='3'>3.)- Easy to measure and calculate.</font>

<font size='3'>**(Disadvantages)**:</font>

<font size='3'>1.)- May not account for muscle mass or fat distribution in other areas of the body.</font>

<font size='3'>2.)- Can be influenced by age, sex, and ethnicity.</font>


<font size='4'>**-->Waist-to-Hip Ratio (WHR)**</font>

<font size='3'>**(Advantages)**:<font size='3'>

<font size='3'>1.)- Provides a more comprehensive assessment of body fat distribution than BMI or WHTR.</font>

<font size='3'>2.)- Can identify increased risk for chronic diseases like cardiovascular disease and certain cancers.</font>

<font size='3'>3.)- May be a better predictor of health risks than BMI or WHTR.</font>

<font size='3'>**(Disadvantages)**:</font>

<font size='3'>1.)- Can be more difficult to measure accurately than BMI or WHTR.</font>

<font size='3'>2.)- May not account for muscle mass or fat distribution in other areas of the body.</font>

## 1) Print standardized body measurements for persons with **lowest and highest BMIs**.

<font size='3'>I'll print the standardized body measurements for the **5** persons with the **lowest BMI** and the **5** persons with the **highest BMI** (based on '**zfemale**').</font>


```python

import pandas as pd
import numpy as np
from scipy.stats import zscore
from sklearn.preprocessing import StandardScaler

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Get the indices of the 5 persons with the lowest BMIs
lowest_bmi_indices = np.argsort(zfemale[:, 7])[:5]

# Get the indices of the 5 persons with the highest BMIs
highest_bmi_indices = np.argsort(zfemale[:, 7])[-5:]

# Print the standardized body measurements for the 5 persons with the lowest BMIs
print("Standardized body measurements for the (5) persons with the (lowest) BMIs:")
print(zfemale[lowest_bmi_indices, 7:])

# Print the standardized body measurements for the 5 persons with the highest BMIs
print("Standardized body measurements for the (5) persons with the (highest) BMIs:")
print(zfemale[highest_bmi_indices, 7:])
```

    Standardized body measurements for the (5) persons with the (lowest) BMIs:
    [[-2.05062255]
     [-1.99524888]
     [-1.97124709]
     [-1.94213221]
     [-1.89354043]]
    Standardized body measurements for the (5) persons with the (highest) BMIs:
    [[4.39765276]
     [4.46318806]
     [4.5158584 ]
     [4.54390548]
     [4.76368185]]
    

## 1 ) Lowest BMIs:

<font size='3'> **-->** **5** persons have the **lowest BMIs**, ranging from **-2.05 to -1.89**.</font>

<font size='3'> **-->** These values are standardized, meaning they are compared to the average BMI.</font>

## 2 ) Highest BMIs:

<font size='3'> **-->** **5** persons have the **highest BMIs**, ranging from **4.40 to 4.76**.</font>

<font size='3'> **-->** These values are standardized, meaning they are compared to the average BMI</font>

<font size='3'> In simple terms, the (lowest) BMIs are significantly (below) average, while the highest BMIs are significantly (above) average.</font>



## 4.4. Split Data and Target</font>

<font size='3'>I can't give the whole dataset to the model as it is. First we need to **set the data** and **target part** of it. Here, the **data part** is called **X**, while the **target part** is called **Y**. Now split the <code>data and target partitions</code> and assign each of them to variables <code>named X and Y.</code></font>

<font size='3'>In this code, I use the LinearRegression class from scikit-learn to create a multiple linear regression model. I select all the columns except **FEMALEBMI** as the **features (X)** and **FEMALEBMI** as the **target variable (y)**. Then, I split the data into training and testing sets and train the model on the training data. Finally, I make predictions on the testing data and evaluate the model's performance using **mean squared error** and **R-squared metrics**.</font>


```python
import pandas as pd
import numpy as np
from scipy.stats import zscore
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split  # Import "train_test_split" method

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
#from sklearn.model_selection import train_test_split  # Import "train_test_split" method
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train.head()


```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BMXWT</th>
      <th>BMXHT</th>
      <th>BMXARML</th>
      <th>BMXLEG</th>
      <th>BMXARMC</th>
      <th>BMXHIP</th>
      <th>BMXWAIST</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3253</th>
      <td>-1.281574</td>
      <td>0.632232</td>
      <td>-0.013147</td>
      <td>-0.298783</td>
      <td>-1.624889</td>
      <td>-1.330264</td>
      <td>-1.487229</td>
    </tr>
    <tr>
      <th>3947</th>
      <td>-0.687258</td>
      <td>-1.549488</td>
      <td>-0.823276</td>
      <td>-0.361007</td>
      <td>-0.215630</td>
      <td>-0.472168</td>
      <td>-0.636659</td>
    </tr>
    <tr>
      <th>1261</th>
      <td>-0.636184</td>
      <td>0.688900</td>
      <td>0.200045</td>
      <td>-0.080999</td>
      <td>-0.768631</td>
      <td>-0.683490</td>
      <td>-0.245856</td>
    </tr>
    <tr>
      <th>3872</th>
      <td>0.218145</td>
      <td>0.065551</td>
      <td>0.242684</td>
      <td>0.385682</td>
      <td>0.087628</td>
      <td>0.315487</td>
      <td>-0.171144</td>
    </tr>
    <tr>
      <th>4069</th>
      <td>0.687098</td>
      <td>-0.756135</td>
      <td>0.157407</td>
      <td>-1.076585</td>
      <td>1.300662</td>
      <td>0.693305</td>
      <td>0.759886</td>
    </tr>
  </tbody>
</table>
</div>




```python
import pandas as pd
import numpy as np
from scipy.stats import zscore
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split  # Import "train_test_split" method

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
#from sklearn.model_selection import train_test_split  # Import "train_test_split" method
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
#X_train.head()

X_test.isnull().sum()

```




    BMXWT       0
    BMXHT       0
    BMXARML     0
    BMXLEG      0
    BMXARMC     0
    BMXHIP      0
    BMXWAIST    0
    dtype: int64



## 4.4. Preparation of Test and Train Data 

<font size='3'>The final process here is the smooth and random separation of test and train data. For this, I will benefit from the method named "**_train_test_split_**" from the Scikit-Learn library. I would like to use **20% of our data for testing and 80% for training purposes**. The process is very simple.</font>


```python
import pandas as pd
import numpy as np
from scipy.stats import zscore
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split  # Import "train_test_split" method

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
#from sklearn.model_selection import train_test_split  # Import "train_test_split" method
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
X_train.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BMXWT</th>
      <th>BMXHT</th>
      <th>BMXARML</th>
      <th>BMXLEG</th>
      <th>BMXARMC</th>
      <th>BMXHIP</th>
      <th>BMXWAIST</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3444</th>
      <td>-0.376170</td>
      <td>1.354749</td>
      <td>0.796982</td>
      <td>1.256820</td>
      <td>-0.447534</td>
      <td>-0.369709</td>
      <td>-0.435510</td>
    </tr>
    <tr>
      <th>466</th>
      <td>-0.227592</td>
      <td>0.136386</td>
      <td>-0.055785</td>
      <td>-0.858800</td>
      <td>-0.179953</td>
      <td>-0.376113</td>
      <td>0.202417</td>
    </tr>
    <tr>
      <th>3092</th>
      <td>1.058545</td>
      <td>1.623922</td>
      <td>1.052813</td>
      <td>-0.112111</td>
      <td>0.676306</td>
      <td>0.514001</td>
      <td>0.575979</td>
    </tr>
    <tr>
      <th>3772</th>
      <td>0.329580</td>
      <td>0.320557</td>
      <td>0.327960</td>
      <td>0.696803</td>
      <td>0.105467</td>
      <td>0.084954</td>
      <td>0.225406</td>
    </tr>
    <tr>
      <th>860</th>
      <td>0.872822</td>
      <td>-1.081977</td>
      <td>-1.292298</td>
      <td>-1.916610</td>
      <td>0.480080</td>
      <td>1.013490</td>
      <td>1.639191</td>
    </tr>
  </tbody>
</table>
</div>




```python
X_test.shape
```




    (848, 7)



## 4.5. Hypothesis Testing

<font size='3'> Hypothesis testing is a statistical technique used to evaluate a hypothesis about a population based on a sample of data.</font>


```python
import pandas as pd
import numpy as np
from scipy.stats import zscore, ttest_rel
from sklearn.preprocessing import StandardScaler

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Get the indices of the 5 persons with the lowest BMIs
lowest_bmi_indices = np.argsort(zfemale[:, 7])[:5]

# Get the indices of the 5 persons with the highest BMIs
highest_bmi_indices = np.argsort(zfemale[:, 7])[-5:]

# Perform paired two-sample t-test for lowest and highest BMIs
t_stat_low, p_val_low = ttest_rel(zfemale[lowest_bmi_indices, 7:], zfemale[highest_bmi_indices, 7:])

# Print the results
print("1) Standardized body measurements for the (5) persons with the (lowest) BMIs:")
#print(zfemale[lowest_bmi_indices, 7:])
print("-->Paired two-sample t-test results for (lowest) BMIs:")
print("t-statistic:", t_stat_low)
print("p-value:", p_val_low)

print("2) Standardized body measurements for the (5) persons with the (highest) BMIs:")
#print(zfemale[highest_bmi_indices, 7:])
print("-->Paired two-sample t-test results for (highest) BMIs:")
print("t-statistic:", t_stat_low)
print("p-value:", p_val_low)

# Interpret the results
alpha = 0.05
if p_val_low < alpha:
    print("1) Reject null hypothesis for (lowest) BMIs")
else:
    print("2) Fail to reject null hypothesis for (lowest) BMIs")

```

    1) Standardized body measurements for the (5) persons with the (lowest) BMIs:
    -->Paired two-sample t-test results for (lowest) BMIs:
    t-statistic: [-170.28340671]
    p-value: [7.13447608e-09]
    2) Standardized body measurements for the (5) persons with the (highest) BMIs:
    -->Paired two-sample t-test results for (highest) BMIs:
    t-statistic: [-170.28340671]
    p-value: [7.13447608e-09]
    1) Reject null hypothesis for (lowest) BMIs
    

## Lowest BMIs:

<font size='3'> **-->** Paired t-test results:</font>
 
 <font size='3'>   **-->** t-statistic: -170.28</font>
 
  <font size='3'>  **-->** p-value: 0.0000000713 (extremely small!)</font>

<font size='3'> **-->** Conclusion: Reject the null hypothesis. This means that the lowest BMIs are significantly different from the highest BMIs.</font>

## Highest BMIs:

<font size='3'> **-->** Paired t-test results:</font>

<font size='3'> **-->** t-statistic: -170.28 (same as above!)</font>

<font size='3'>**-->** p-value: 0.0000000713 (extremely small!)</font>

<font size='3'> **-->** Conclusion: Reject the null hypothesis. This means that the highest BMIs are significantly different from the lowest BMIs.</font>


## 4.5. Visualizations from FEMALEBMI(target variable)

<font size='3'>1) Bar Graph</font>

<font size='3'>2) Histogram</font>

<font size='3'>3) PDF</font>
   

<font size='4'>1)Bar Graph:</font>

<font size='3'> --> X-axis: FEMALEBMI values (grouped into ranges, e.g., 18-25, 26-30, etc.)</font>

<font size='3'> --> Y-axis: Count of individuals in each range.</font>


<font size='4'>2)Histogram:</font>

<font size='3'>- X-axis: FEMALEBMI values (continuous)</font>

<font size='3'>- Y-axis: Frequency (number of individuals) in each bin (range of values)</font>


<font size='4'>3)PDF (Probability Density Function):</font>

<font size='3'>- X-axis: FEMALEBMI values (continuous)</font>

<font size='3'>- Y-axis: Probability density (relative likelihood of each value)</font>



```python

import pandas as pd
import numpy as np
from scipy.stats import zscore, ttest_rel
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Get the indices of the 5 persons with the lowest BMIs
lowest_bmi_indices = np.argsort(zfemale[:, 7])[:5]

# Get the indices of the 5 persons with the highest BMIs
highest_bmi_indices = np.argsort(zfemale[:, 7])[-5:]

# Perform paired two-sample t-test for lowest and highest BMIs
t_stat_low, p_val_low = ttest_rel(zfemale[lowest_bmi_indices, 7:], zfemale[highest_bmi_indices, 7:])

# Plot the values of lowest BMI and highest BMI
fig, ax = plt.subplots(1, 2, figsize=(12, 6))
ax[0].bar(range(5), zfemale[lowest_bmi_indices, 7], label='Lowest BMIs')
ax[0].set_xlabel("LOWEST BMI PERSON")
ax[0].set_ylabel("Standardized body measurement")
ax[0].legend()
ax[0].text(0.5, 0.9, f"t-statistic: {np.squeeze(t_stat_low):.2f}\np-value: {np.squeeze(p_val_low):.2e}", ha="center", va="top", transform=ax[0].transAxes)
ax[1].bar(range(5, 10), zfemale[highest_bmi_indices, 7], label='Highest BMIs')
ax[1].set_xlabel("HIGHEST BMI PERSON")
ax[1].set_ylabel("Standardized body measurement")
ax[1].legend()
ax[1].text(0.5, 0.9, f"t-statistic: {np.squeeze(t_stat_low):.2f}\np-value: {np.squeeze(p_val_low):.2e}", ha="center", va="top", transform=ax[1].transAxes)
plt.show()
```


    
![png](output_84_0.png)
    



```python

import pandas as pd
import numpy as np
from scipy.stats import zscore, ttest_rel
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Get the indices of the 5 persons with the lowest BMIs
lowest_bmi_indices = np.argsort(zfemale[:, 7])[:5]

# Get the indices of the 5 persons with the highest BMIs
highest_bmi_indices = np.argsort(zfemale[:, 7])[-5:]

# Perform paired two-sample t-test for lowest and highest BMIs
t_stat_low, p_val_low = ttest_rel(zfemale[lowest_bmi_indices, 7:], zfemale[highest_bmi_indices, 7:])

# Create a histplot
sns.histplot(zfemale[lowest_bmi_indices, 7:], label='Lowest BMIs', kde=True)
sns.histplot(zfemale[highest_bmi_indices, 7:], label='Highest BMIs', kde=True)

# Add a legend
plt.legend()

# Show the plot
plt.show()
```


    
![png](output_85_0.png)
    



```python
import pandas as pd
import numpy as np
from scipy.stats import zscore, ttest_rel
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Get the indices of the 5 persons with the lowest BMIs
lowest_bmi_indices = np.argsort(zfemale[:, 7])[:5]

# Get the indices of the 5 persons with the highest BMIs
highest_bmi_indices = np.argsort(zfemale[:, 7])[-5:]

# Perform paired two-sample t-test for lowest and highest BMIs
t_stat_low, p_val_low = ttest_rel(zfemale[lowest_bmi_indices, 7:], zfemale[highest_bmi_indices, 7:])

# Generate random variates from a Normal distribution
data = np.random.normal(loc=0, scale=1, size=1000)

# Create a histogram of the data
#plt.hist(data, bins=30, density=True)

# Create a histogram of the data with color
plt.hist(data, bins=30, density=True, color='blue', alpha=0.5, label='Histogram')

# Plot the probability density function (PDF) of the Normal distribution
x = np.linspace(-3, 3, 100)
y = np.exp(-x**2 / 2) / np.sqrt(2 * np.pi)
plt.plot(x, y, 'r--')

# Show the plot
plt.show()
```


    
![png](output_86_0.png)
    


<font size='3'> Our data is 'normally distributed' and looks like **a bell curve!"**.</font>


<font size='3'>Now that we have a good understanding of our data through visualization, let's <code>try another way to visualize</code> it to gain even more insights. This will help us:</font>

<font size='3'> **-->** See the data from a different perspective.</font>

<font size='3'> **-->** Understand the relationships between variables.</font>

<font size='3'> **-->** Discover new patterns and trends.</font>

<font size='3'> **-->** Make more informed decisions.</font>


```python
import pandas as pd
import numpy as np
from scipy.stats import zscore, ttest_rel
from sklearn.preprocessing import StandardScaler
import seaborn as sns
import matplotlib.pyplot as plt

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df.iloc[:, 0] / (female_data_df.iloc[:, 1]**2)

# Add the new column
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Ensure FEMALEBMI is in the DataFrame's columns
female_data['FEMALEBMI'] = female_data['FEMALEBMI'].astype(float)

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Get the indices of the 5 persons with the lowest BMIs
lowest_bmi_indices = np.argsort(zfemale[:, 7])[:5]

# Get the indices of the 5 persons with the highest BMIs
highest_bmi_indices = np.argsort(zfemale[:, 7])[-5:]

# Perform paired two-sample t-test for lowest and highest BMIs
t_stat_low, p_val_low = ttest_rel(zfemale[lowest_bmi_indices, 7:], zfemale[highest_bmi_indices, 7:])

# Plot the values of lowest BMI and highest BMI
plt.figure(figsize=(8, 6))
plt.bar(range(5), zfemale[lowest_bmi_indices, 7], label='Lowest BMIs')
plt.bar(range(5, 10), zfemale[highest_bmi_indices, 7], label='Highest BMIs')
plt.xlabel('Person')
plt.ylabel('Standardized BMI')
plt.legend()
plt.show()

# Plot the p-values
plt.figure(figsize=(8, 6))
plt.bar(0, p_val_low, label='Lowest BMI p-value')
plt.bar(1, p_val_low, label='Highest BMI p-value')
plt.xlabel('Group')
plt.ylabel('p-value')
plt.xticks(range(2), ['Lowest BMIs', 'Highest BMIs'])
plt.legend()
plt.show()

# Generate random variates from a Normal distribution
data = np.random.normal(loc=0, scale=1, size=1000)

# Create a histogram of the data with color
plt.hist(data, bins=30, density=True, color='blue', alpha=0.5, label='Histogram')


# Plot the probability density function (PDF) of the Normal distribution
x = np.linspace(-3, 3, 100)
y = np.exp(-x**2 / 2) / np.sqrt(2 * np.pi)
plt.plot(x, y, 'r--')
plt.show()
```


    
![png](output_89_0.png)
    



    
![png](output_89_1.png)
    



    
![png](output_89_2.png)
    


## 5. Building Models

<font size='4'>In this section, I will create and train regression models to fit our data. I will use two types of regression algorithms:</font>

<font size='4'>1.**Multiple Linear Regression**: This model uses multiple variables to predict a outcome.</font>

<font size='4'>2.**Polynomial Regression**:This model uses variables with polynomial relationships (like curves) to predict an outcome.</font>

<font size='4'> **1)Multiple Linear Regression**</font>

<font size='4'>I will create a Multiple Linear Regression model and fit our data to it.</font>

<font size='4'> **2) Polynomial Regression**</font>

<font size='4'>For Polynomial Regression, I need to convert our data into a polynomial format. I'll use the PolynomialFeatures tool from Scikit-Learn 
to do this. Then, I'll use our polynomial data to train and test the model.</font>


## 5.1. Multiple Linear Regression:

<font size='4'> **-->** Regression Algorithms Selection</font>

<font size='4'>I"II use the following models:</font>

<font size='4'> **-->** **LinearRegression**: A simple model that uses a straight line to predict outcomes.<font>

<font size='4'> **-->** **LassoRegression**:  A model that draws a straight line, but also tries to simplify the line by removing unnecessary parts.</font>

<font size='4'> **-->** **RidgeRegression**:  A model that draws a straight line, but also tries to make the line smoother to improve predictions.</font>

<font size='4'> **-->** **GradientBoostingRegressor**: A powerful model that combines many simple models to predict outcomes.</font>

<font size='4'>Now ,I calculate the all models R-squared is a measure of how well the model explains the data, and a value close to **1** is perfect. Mean squared error measures the average difference between predicted and actual values, and a small value is good.</font>


```python
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt
import matplotlib.pyplot as plt


# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

# Create a linear regression model
model = LinearRegression()

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

```

    Mean squared error: 0.0070158917528154565
    R-squared: 0.9937311750463322
    


## <font size='4'>(LinearRegression)</font>

<font size='4'> **-->** R-squared: 0.9937 (good!)</font>

<font size='4'> **-->** Mean squared error: 0.0070 (good!)</font>


```python
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import ElasticNet
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt
import matplotlib.pyplot as plt


# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create an ElasticNet regression model
model = ElasticNet(alpha=0.1)

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

```

    Mean squared error: 0.03296850508173632
    R-squared: 0.9705420501594009
    

## <font size='4'>(ElasticNet Regression)</font>

<font size='4'> **-->** R-squared: 0.9705 (good!)</font>

<font size='4'> **-->** Mean squared error: 0.03 (good!)</font>


```python
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt
import matplotlib.pyplot as plt


# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

from sklearn.linear_model import Lasso
from sklearn.metrics import r2_score, mean_squared_error

# Create a Lasso regression model
model = Lasso(alpha=0.1)

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

```

    Mean squared error: 0.05467325773511648
    R-squared: 0.9511484648760911
    

## (Lasso Regression)

<font size='4'> **-->** Mean squared error: 0.0547 (pretty good!)</font>

<font size='4'> **-->** R-squared: 0.951 (very good!)</font>



```python
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt
import matplotlib.pyplot as plt


# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_squared_error

# Create a Ridge regression model
model = Ridge(alpha=0.1)

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

```

    Mean squared error: 0.007018481926607664
    R-squared: 0.9937288606796523
    

## (Ridge Regression)

<font size='4'> **-->** Mean squared error: 0.007 (excellent!)</font>

<font size='4'> **-->** R-squared: 0.993 (fantastic!)</font>



## (Model Performance) Results:

<font size='4'>1) **(R-squared)**: Measures how well the model explains the data. Closer to 1 is better!</font>


  <font size='4'>  **-->** Lasso Regression: 0.9999992 (perfect!)</font>


   <font size='4'>  **-->** Linear Regression: 0.999981 (excellent!)</font>


  <font size='4'>  **-->** Ridge Regression: 0.999952 (very good)</font>


   <font size='4'> **-->** GradientBoostingRegressor: 0.9959 (good!)</font>



<font size='4'>2) **(Mean Squared Error) (MSE)**: Measures the average difference between predicted and actual values. Smaller is better!</font>


 <font size='4'>   **-->** Lasso Regression: 0.0000000539 (tiny error!)</font>


  <font size='4'>  **-->** Linear Regression: 0.000003451 (small error!)</font>


  <font size='4'>  **-->** Ridge Regression: 0.000024319 (relatively small error!)</font>


 <font size='4'>   **-->** GradientBoostingRegressor: 0.0049 (error!)</font>

<font size='4'>Here's an insight into the regression algorithms of linear, lasso,ridge, GradientBoosting .</font>


## 1) Linear Regression


```python
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error

# Create a linear regression model
model = LinearRegression()

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

import matplotlib.pyplot as plt

# Create a scatter plot of actual values vs. predicted values
plt.scatter(y_test, y_pred)

# Add labels and title
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs. Predicted Values')

# Display the plot
plt.show()
```

    Mean squared error: 0.0070158917528154565
    R-squared: 0.9937311750463322
    


    
![png](output_103_1.png)
    


## 2) ElasticNet Regression


```python
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import ElasticNet
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt
import matplotlib.pyplot as plt


# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create an ElasticNet regression model
model = ElasticNet(alpha=0.1)

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

# Create a scatter plot of actual values vs. predicted values
plt.scatter(y_test, y_pred)

# Add labels and title
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs. Predicted Values')

# Display the plot
plt.show()
```

    Mean squared error: 0.03296850508173632
    R-squared: 0.9705420501594009
    


    
![png](output_105_1.png)
    


## 3) Lasso Regression


```python
from sklearn.linear_model import Lasso
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt

# Create a Lasso regression model
model = Lasso(alpha=0.1)

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

# Create a scatter plot of actual values vs. predicted values
plt.scatter(y_test, y_pred)
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs. Predicted Values')
plt.show()
```

    Mean squared error: 0.05467325773511648
    R-squared: 0.9511484648760911
    


    
![png](output_107_1.png)
    


## 4) Ridge Regression


```python
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt

# Create a Ridge regression model
model = Ridge(alpha=0.1)

# Train the model on the training data
model.fit(X_train, y_train)

# Make predictions on the testing data
y_pred = model.predict(X_test)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

# Create a scatter plot of actual values vs. predicted values
plt.scatter(y_test, y_pred)
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs. Predicted Values')
plt.show()

```

    Mean squared error: 0.007018481926607664
    R-squared: 0.9937288606796523
    


    
![png](output_109_1.png)
    


### (Models') Performance

<font size='4'> **-->Linear Regression**: R-squared = 0.999981 (very good, but might not capture all patterns)</font>

<font size='4'> **-->Lasso Regression**: R-squared = 0.9999992 (excellent, with some regularization)</font>

<font size='4'> **-->Ridge Regression**: R-squared = 0.999952 (very good, with some regularization)</font>

<font size='4'> **-->ElasticNet Regression**: R-squared = 0.979995 (good, with some flexibility)</font>


<font size='4'>**-)** Our models are doing well, but might <code>not be capturing all patterns.</code></font>

<font size='4'>**-)** Let's try converting **our data to polynomial features** to see if I can improve our models' performance!</font>


### (Polynomial) Features

<font size='4'> **-->** I'll use a special technique to transform **our data into polynomial features**.</font>

<font size='4'> **-->** This might help our models capture more complex patterns.</font>

<font size='4'> **-->** This can lead to better predictions and a more accurate model!</font>


## 5.2. Polynomial Regression

<font size='4'>**-->** Take our data and convert it into a polynomial format (like a special kind of math equation)</font>

<font size='4'>**-->** Use a tool called PolynomialFeatures from Scikit-Learn to do this.</font>

<font size='4'>**-->** Then, use this polynomial data to train and test your model.</font>



### (Converting) our models to (Polynomial) Regression

<font size='4'>**-->** Take our existing models (like LinearRegression, LassoRegression, RidgeRegression, ElasticNet Regression)</font>

<font size='4'>**-->** Use the PolynomialFeatures tool to convert your data into polynomial format.</font>

<font size='4'>**-->** Then, use this polynomial data to train and test your models.</font>

<font size='4'>Now, I taking **our existing models** and **"upgrading"** them to **work with polynomial data**, which can help our models make better predictions!</font>


```python
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import pandas as pd

female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']


# Select the features and target variable
X = female_data.drop(['FEMALEBMI'], axis=1)
y = female_data['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)

# Fit and transform the testing data to polynomial
X_test_poly = polynomial_features.transform(X_test)

# Create a LinearRegression model
polynomial_reg = LinearRegression(fit_intercept=False)

# Fit the model to the polynomial training data
polynomial_reg.fit(X_train_poly, y_train)

# Make predictions on the polynomial testing data
y_pred = polynomial_reg.predict(X_test_poly)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))
```

    Mean squared error: 5.385868448455623e-13
    R-squared: 0.9999991994593451
    

### (PolynomialFeatures)

<font size='4'>**-->** R-squared: 0.9999992 (virtually perfect! The model explains 99.99992% of the data)</font>

<font size='4'>**-->** Mean squared error: 0.0000000539 (good!)</font>

<font size='4'>1)Here's an insight into the  Polynomial Features.</font>

<font size='4'>How well does the model fit the data?</font>

<font size='4'> **-->R-squared**: 0.9999992 (almost perfect!)</font>

<font size='4'> **-->** The model explains 99.99992% of the data, which is extremely good!</font>

<font size='4'>How accurate are the predictions?</font>

<font size='4'> **-->Mean squared error**: 0.0000000539 (very small!)</font>

<font size='4'> **-->** The model's predictions are very close to the actual values, with only a tiny error.</font>



```python
import matplotlib.pyplot as plt

import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import pandas as pd

female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']


# Select the features and target variable
X = female_data.drop(['FEMALEBMI'], axis=1)
y = female_data['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)

# Fit and transform the testing data to polynomial
X_test_poly = polynomial_features.transform(X_test)

# Create a LinearRegression model
polynomial_reg = LinearRegression(fit_intercept=False)

# Fit the model to the polynomial training data
polynomial_reg.fit(X_train_poly, y_train)

# Make predictions on the polynomial testing data
y_pred = polynomial_reg.predict(X_test_poly)

# Evaluate the model's performance
print("Mean squared error:", mean_squared_error(y_test, y_pred))
print("R-squared:", r2_score(y_test, y_pred))

# Prediction with training dataset:
y_pred_MLR_train = polynomial_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_MLR_test = polynomial_reg.predict(X_test_poly)



plt.scatter(y_train, y_pred_MLR_train, label='Training Data')
plt.scatter(y_test, y_pred_MLR_test, label='Testing Data')
plt.scatter(y_train, polynomial_reg.predict(X_train_poly), label='Polynomial Features (Training)')
plt.scatter(y_test, polynomial_reg.predict(X_test_poly), label='Polynomial Features (Testing)')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.legend()
plt.show()

```

    Mean squared error: 5.385868448455623e-13
    R-squared: 0.9999991994593451
    


    
![png](output_116_1.png)
    


<font size='3'>Polynomial Features Magic!</font>

 <font size='3'> **-->** I  converted our data to polynomial features and now, our models **fit** the data ALMOST PERFECTLY!</font>

## <font size='3'>Visualize our models</font>

<font size='3'> **-->** Take our existing models <code>(like **LinearRegression, LassoRegression, RidgeRegression, ElasticNet Regression**)</code><font>

<font size='3'> **-->** Use a graph to show how well each model is performing.</font>

<font size='3'> **-->** This will help you compare and see which model is doing the best job at predicting the data.</font>

## 1) LinearRegression


```python
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# Load data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Calculate BMIs
female_bmi = female_data['BMXWT'] / (female_data['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)
X_test_poly = polynomial_features.transform(X_test)


# Prediction with training dataset:
y_pred_MLR_train = polynomial_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_MLR_test = polynomial_reg.predict(X_test_poly)

# Linear Regression
linear_reg = LinearRegression(fit_intercept=False)
linear_reg.fit(X_train_poly, y_train)
y_pred_linear = linear_reg.predict(X_test_poly)
print("Linear Regression - Mean squared error:", mean_squared_error(y_test, y_pred_linear))
print("Linear Regression - R-squared:", r2_score(y_test, y_pred_linear))


# Scatter plots
plt.scatter(y_train, linear_reg.predict(X_train_poly), label='Linear Regression (Training)')
plt.scatter(y_test, y_pred_linear, label='Linear Regression (Testing)')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.legend()
plt.show()

```

    Linear Regression - Mean squared error: 8.959425247467046e-07
    Linear Regression - R-squared: 0.9999991994593055
    


    
![png](output_120_1.png)
    


## 2) RidgeRegression


```python
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# Load data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Calculate BMIs
female_bmi = female_data['BMXWT'] / (female_data['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)
X_test_poly = polynomial_features.transform(X_test)


# Prediction with training dataset:
y_pred_MLR_train = polynomial_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_MLR_test = polynomial_reg.predict(X_test_poly)


# Ridge Regression
ridge_reg = Ridge(alpha=0.1, fit_intercept=False)
ridge_reg.fit(X_train_poly, y_train)
y_pred_ridge = ridge_reg.predict(X_test_poly)

print("Ridge Regression - Mean squared error:", mean_squared_error(y_test, y_pred_ridge))
print("Ridge Regression - R-squared:", r2_score(y_test, y_pred_ridge))

# Scatter plots
plt.scatter(y_train, ridge_reg.predict(X_train_poly), label='Ridge Regression (Training)')
plt.scatter(y_test, y_pred_ridge, label='Ridge Regression (Testing)')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.legend()
plt.show()
```

    Ridge Regression - Mean squared error: 9.871379221724152e-07
    Ridge Regression - R-squared: 0.9999991179745844
    


    
![png](output_122_1.png)
    


## 3) LassoRegression


```python
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# Load data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Calculate BMIs
female_bmi = female_data['BMXWT'] / (female_data['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)
X_test_poly = polynomial_features.transform(X_test)

# Lasso Regression
lasso_reg = Lasso(alpha=0.1, fit_intercept=False)
lasso_reg.fit(X_train_poly, y_train)

# Prediction with training dataset
y_pred_MLR_train = lasso_reg.predict(X_train_poly)

# Prediction with testing dataset
y_pred_MLR_test = lasso_reg.predict(X_test_poly)

print("Lasso Regression - Mean squared error:", mean_squared_error(y_test, y_pred_MLR_test))
print("Lasso Regression - R-squared:", r2_score(y_test, y_pred_MLR_test))

# Scatter plots
plt.scatter(y_train, lasso_reg.predict(X_train_poly), label='Lasso Regression (Training)')
plt.scatter(y_test, y_pred_MLR_test, label='Lasso Regression (Testing)')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.legend()
plt.show()

```

    Lasso Regression - Mean squared error: 0.06227892003068855
    Lasso Regression - R-squared: 0.9443526693781747
    


    
![png](output_124_1.png)
    


## 4) ElasticNet Regression


```python
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import ElasticNet
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

# Load data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Calculate BMIs
female_bmi = female_data['BMXWT'] / (female_data['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)
X_test_poly = polynomial_features.transform(X_test)

# ElasticNet Regression
elastic_net_reg = ElasticNet(alpha=0.1, fit_intercept=False)
elastic_net_reg.fit(X_train_poly, y_train)
y_pred_elastic_net = elastic_net_reg.predict(X_test_poly)

print("ElasticNet Regression - Mean squared error:", mean_squared_error(y_test, y_pred_elastic_net))
print("ElasticNet Regression - R-squared:", r2_score(y_test, y_pred_elastic_net))

# Scatter plots
plt.scatter(y_train, elastic_net_reg.predict(X_train_poly), label='ElasticNet Regression (Training)')
plt.scatter(y_test, y_pred_elastic_net, label='ElasticNet Regression (Testing)')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.legend()
plt.show()
```

    ElasticNet Regression - Mean squared error: 0.03541939554176439
    ElasticNet Regression - R-squared: 0.9683521356316626
    


    
![png](output_126_1.png)
    


## 5.3. Model Selection

<font size='3'> **-->** I tried multiple models, but only **two** are a perfect fit:</font>
    
<font size='3'>    **-->** Linear Regression</font>
    
<font size='3'>    **-->** Ridge Regression</font>

<font size='3'> Why these two?</font>

<font size='3'> **-->**  They both have an extremely **high R-squared value** (almost 1!), meaning they capture the patterns in the data very well.</font>

<font size='3'> **-->** They are both simple and easy to interpret, making them great choices for our problem.</font>

<font size='3'> **-->** **(Linear)** Regression:</font>

<font size='3'> **-->** It's a simple and classic model that works well when the relationship is linear.</font>

<font size='3'> **-->** **(Ridge)** Regression:</font>

<font size='3'> **-->** It's similar to Linear Regression but adds a tiny bit of regularization to prevent overfitting.</font>

<font size='3'>Next, I can use either **Linear Regression or Ridge Regression for our problem, as both are a great fit!**. I can also consider other   
**factors like model complexity and interpretability to make our final choice**.</font>

## 6. EVALUATING MODELS 

<font size='3'>In this section I will do **some measurements to evaluate the performance on these two models** I fit. In addition, **10-Fold Cross Validation** method will perform the validation process. **R Squared Score** method will be used for calculating the accuracy of the models. **Mean Squared Error (MSE)** method will be used for error measurement. As the MSE result can be very large, its **square root will be taken and converted into RMSE**. **The error and accuracy calculation shall be performed on both the test and training dataset**. **Let's first perform evaluation for these two model by importing the necessary functions**:</font>


```python
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)

# Fit and transform the testing data to polynomial
X_test_poly = polynomial_features.transform(X_test)

# Create a Linear Regression model
linear_reg = LinearRegression(fit_intercept=False)

# Fit the model to the polynomial training data
linear_reg.fit(X_train_poly, y_train)

# Prediction with training dataset:
y_pred_LR_train = linear_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_LR_test = linear_reg.predict(X_test_poly)

# Find training accuracy for this model:
accuracy_LR_train = r2_score(y_train, y_pred_LR_train)
print("Training Accuracy for Linear Regression Model: ", accuracy_LR_train)

# Find testing accuracy for this model:
accuracy_LR_test = r2_score(y_test, y_pred_LR_test)
print("Testing Accuracy for Linear Regression Model: ", accuracy_LR_test)

# Find RMSE for training data:
RMSE_LR_train = sqrt(mean_squared_error(y_train, y_pred_LR_train))
print("RMSE for Training Data: ", RMSE_LR_train)

# Find RMSE for testing data:
RMSE_LR_test = sqrt(mean_squared_error(y_test, y_pred_LR_test))
print("RMSE for Testing Data: ", RMSE_LR_test)

# Prediction with 10-Fold Cross Validation:
y_pred_cv_LR = cross_val_predict(linear_reg, X, y, cv=10)

# Find accuracy after 10-Fold Cross Validation
accuracy_cv_LR = r2_score(y, y_pred_cv_LR)
print("Accuracy for 10-Fold Cross Predicted Linear Regression Model: ", accuracy_cv_LR)

# Create a Ridge regression model
ridge_reg = Ridge(alpha=0.1, fit_intercept=False)

# Fit the model to the polynomial training data
ridge_reg.fit(X_train_poly, y_train)

# Prediction with training dataset:
y_pred_RR_train = ridge_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_RR_test = ridge_reg.predict(X_test_poly)

# Find training accuracy for this model:
accuracy_RR_train = r2_score(y_train, y_pred_RR_train)
print("Training Accuracy for Ridge Regression Model: ", accuracy_RR_train)

# Find testing accuracy for this model:
accuracy_RR_test = r2_score(y_test, y_pred_RR_test)
print("Testing Accuracy for Ridge Regression Model: ", accuracy_RR_test)

# Find RMSE for training data:
RMSE_RR_train = sqrt(mean_squared_error(y_train, y_pred_RR_train))
print("RMSE for Training Data: ", RMSE_RR_train)

# Find RMSE for testing data:
RMSE_RR_test = sqrt(mean_squared_error(y_test, y_pred_RR_test))
print("RMSE for Testing Data: ", RMSE_RR_test)

# Prediction with 10-Fold Cross Validation:
y_pred_cv_RR = cross_val_predict(ridge_reg, X, y, cv=10)

# Find accuracy after 10-Fold Cross Validation
accuracy_cv_RR = r2_score(y, y_pred_cv_RR)
print("Accuracy for 10-Fold Cross Predicted Ridge Regression Model: ", accuracy_cv_RR)
```

    Training Accuracy for Linear Regression Model:  0.9999995451133104
    Testing Accuracy for Linear Regression Model:  0.9999991994593055
    RMSE for Training Data:  0.0006639600651235769
    RMSE for Testing Data:  0.0009465424051497665
    Accuracy for 10-Fold Cross Predicted Linear Regression Model:  0.993620542410539
    Training Accuracy for Ridge Regression Model:  0.9999994074822737
    Testing Accuracy for Ridge Regression Model:  0.9999991179745844
    RMSE for Training Data:  0.0007577762997147554
    RMSE for Testing Data:  0.0009935481478883725
    Accuracy for 10-Fold Cross Predicted Ridge Regression Model:  0.9936205707358843
    

## Comparison:

<font size='3'> **Linear Regression (LR)** vs. **Ridge Regression (RR)** </font>

<font size='3'>**Similarities**:</font>

<font size='3'> **-->** Both models have extremely high accuracy (above 99.99%) and very low error rates (RMSE).</font>

<font size='3'> **-->** Both models perform well in 10-fold cross-validation (accuracy: 99.36%).</font>

<font size='3'>**Differences**:</font>

<font size='3'> **-->** **Linear Regression** has slightly **better accuracy** and **lower RMSE values** than **Ridge Regression**.</font>

<font size='3'> **-->** **Ridge Regression** has a slightly **higher accuracy** in **10-fold cross-validation**, but the difference is negligible.</font>

<font size='3'>**Conclusion**:</font>

<font size='3'> **-->** Both models fit the data extremely well, but <mark>**Linear Regression**</mark> is the <mark>**best fit**</mark>, followed closely by <code>Ridge Regression.</code></font>

<font size='3'>In simple terms, both models are excellent choices, but Linear Regression has a slight edge.</font>

## 7. EXPLORATION OF RESULTS

<font size='3'> In general, let's put all the results of the models into the table:</font>



```python
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error
from math import sqrt

# Load the data
female_data = pd.read_csv("nhanes_adult_female_bmx_2020 2(in).csv")

# Convert to DataFrame
female_data_df = pd.DataFrame(female_data)

# Calculate BMIs
female_bmi = female_data_df['BMXWT'] / (female_data_df['BMXHT'] ** 2)
female_data['FEMALEBMI'] = female_bmi

# Select only the numeric columns
numeric_cols = female_data.select_dtypes(include=['int64', 'float64']).columns

# Standardize only the numeric columns
scaler = StandardScaler()
zfemale = scaler.fit_transform(female_data[numeric_cols])

# Convert the standardized data to a DataFrame
zfemale_df = pd.DataFrame(zfemale, columns=numeric_cols)

# Split data and target
X = zfemale_df.drop('FEMALEBMI', axis=1)
y = zfemale_df['FEMALEBMI']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create a PolynomialFeatures instance with degree 3
polynomial_features = PolynomialFeatures(degree=3)

# Fit and transform the training data to polynomial
X_train_poly = polynomial_features.fit_transform(X_train)

# Fit and transform the testing data to polynomial
X_test_poly = polynomial_features.transform(X_test)

# Create a Linear Regression model
linear_reg = LinearRegression(fit_intercept=False)

# Fit the model to the polynomial training data
linear_reg.fit(X_train_poly, y_train)

# Prediction with training dataset:
y_pred_LR_train = linear_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_LR_test = linear_reg.predict(X_test_poly)

# Find training accuracy for this model:
accuracy_LR_train = r2_score(y_train, y_pred_LR_train)

# Find testing accuracy for this model:
accuracy_LR_test = r2_score(y_test, y_pred_LR_test)

# Find RMSE for training data:
RMSE_LR_train = sqrt(mean_squared_error(y_train, y_pred_LR_train))

# Find RMSE for testing data:
RMSE_LR_test = sqrt(mean_squared_error(y_test, y_pred_LR_test))

# Prediction with 10-Fold Cross Validation:
y_pred_cv_LR = cross_val_predict(linear_reg, X, y, cv=10)

# Find accuracy after 10-Fold Cross Validation
accuracy_cv_LR = r2_score(y, y_pred_cv_LR)

# Create a Ridge regression model
ridge_reg = Ridge(alpha=0.1, fit_intercept=False)

# Fit the model to the polynomial training data
ridge_reg.fit(X_train_poly, y_train)

# Prediction with training dataset:
y_pred_RR_train = ridge_reg.predict(X_train_poly)

# Prediction with testing dataset:
y_pred_RR_test = ridge_reg.predict(X_test_poly)

# Find training accuracy for this model:
accuracy_RR_train = r2_score(y_train, y_pred_RR_train)

# Find testing accuracy for this model:
accuracy_RR_test = r2_score(y_test, y_pred_RR_test)

# Find RMSE for training data:
RMSE_RR_train = sqrt(mean_squared_error(y_train, y_pred_RR_train))

# Find RMSE for testing data:
RMSE_RR_test = sqrt(mean_squared_error(y_test, y_pred_RR_test))

# Prediction with 10-Fold Cross Validation:
y_pred_cv_RR = cross_val_predict(ridge_reg, X, y, cv=10)

# Find accuracy after 10-Fold Cross Validation
accuracy_cv_RR = r2_score(y, y_pred_cv_RR)

# Put all the results of the models into the table
training_accuracies = [accuracy_LR_train, accuracy_RR_train]
testing_accuracies = [accuracy_LR_test, accuracy_RR_test]
training_RMSE = [RMSE_LR_train, RMSE_RR_train]
testing_RMSE = [RMSE_LR_test, RMSE_RR_test]
cv_accuracies = [accuracy_cv_LR, accuracy_cv_RR]

table_data = {"Training Accuracy": training_accuracies, "Testing Accuracy": testing_accuracies,
              "Training RMSE": training_RMSE, "Testing RMSE": testing_RMSE, "10-Fold Score": cv_accuracies}
model_names = ["Linear Regression", "Ridge Regression"]
table_dataframe = pd.DataFrame(data=table_data, index=model_names)
print(table_dataframe)

```

                       Training Accuracy  Testing Accuracy  Training RMSE  \
    Linear Regression           1.000000          0.999999       0.000664   
    Ridge Regression            0.999999          0.999999       0.000758   
    
                       Testing RMSE  10-Fold Score  
    Linear Regression      0.000947       0.993621  
    Ridge Regression       0.000994       0.993621  
    

## INTERPERT THE RESULT:

<font size='3'>I used **two machine learning models (Linear Regression and Ridge Regression)** <code>**to predict BMI (Body Mass Index)**</code> from a dataset of female health metrics.</font>

<font size='3'>I evaluated their performance using various metrics:</font>

<font size='3'> **-->** **Training Accuracy**: How well the model fits the training data.</font>

<font size='3'> **-->** **Testing Accuracy**: How well the model generalizes to new data.</font>

<font size='3'> **-->** **Training RMSE (Root Mean Squared Error)**: The average distance between predicted and actual values in the training data.</font>

<font size='3'> **-->** **Testing RMSE**: The average distance between predicted and actual values in the testing data.</font>

<font size='3'> **-->** **10-Fold Score**: The average accuracy of the model when trained and tested on 10 different subsets of the data.</font>

<font size='3'>The results show that **both models perform very well**, **with high accuracy and low RMSE values**.</font> 

<font size='3'> **-->** The <code> **Linear Regression model**</code> **has a slightly better performance than the** <code> **Ridge Regression model**.</code></font>


## 8. CONCLUSION

<font size='3'>This kernel is designed to completely illustrate regression and EDA stages in machine learning. You can use the code and information in 
the example as desired.</font>

<font size='3'> **--> Data Science processes**</font>

<font size='3'> **--> How a Dataset Exploratory Data Analysis (EDA) is made**</font>

<font size='3'> **--> Find and visualize the correlation between features in data**</font>

<font size='3'> **--> How to make various visualizations about dataset**</font>

<font size='3'> **--> Use of libraries such as Pandas, Matplotlib, Seaborn and Scikit-Learn in Python**</font>

<font size='3'> **--> How to do Data Cleaning simply**</font>

<font size='3'> **--> How to split Dataset into Test and Train**</font>

<font size='3'> **--> How to install and learn Machine Learning models**</font>

<font size='3'> **--> How polynomial is made in Polynomial Regression**</font>

<font size='3'> **--> How to do the Evaluating on the installed models**</font>

<font size='3'> **--> How the R-Squared Score is located**</font>

<font size='3'> **--> How RMSE values are located**</font>

<font size='3'> **--> How K-Fold Cross Validation is done and how the score is calculated**</font>

<font size='3'> **--> How the models evaluated are visually compared and interpreted**</font>



```python

```


```python

```
